from Caccia import *

n=int(input("Inserisci il numero di righe \n --> "))
m=int(input("Inserisci il numero di colonne \n --> "))
caccia=Caccia(n,m)
caccia.stampaBella()
caccia.stampaBella2()
while caccia.getPreso()==False:
    plx=int(input("Inserisci di seguito la posizione x del colpo \n --> "))
    ply=int(input("Inserisci di seguito la posizione y del colpo \n --> "))
    plx-=1
    ply-=1
    caccia.gioca(plx, ply)
    caccia.stampaBella()

print("Hai vinto")
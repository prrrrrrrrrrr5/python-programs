import random
class Caccia:
    def __init__(self,n,m):
        self.__n=n
        self.__m=m
        self.campo()
        self.tabella()
        self.__preso=False
    def getPreso(self):
        return self.__preso
    def getTabella(self):
        return self.__tabella
    def coniglio(self):
        x=random.randint(0,self.__n)
        y=random.randint(0,self.__m)
        while self.__campo[x][y]!="X":
            self.__conx=x
            self.__cony=y
        del self.__tabella[self.__conx][self.__cony]
        self.__tabella[self.__conx].insert(self.__cony,"C")
    def campo(self):
        self.__campo=[]
        l1=[]
        for i in range(self.__n):
            l1=[]
            for j in range(self.__m):
                l1.append(0)
            self.__campo.append(l1)
    def tabella(self):
        self.__tabella=[]
        l1=[]
        for i in range(self.__n):
            l1=[]
            for j in range(self.__m):
                l1.append(0)
            self.__tabella.append(l1)
    def gioca(self,plx,ply):
        if self.__campo[plx][ply]!="X":
            if self.__tabella[plx][ply]=="C":
                self.__preso=True
            else:
                del self.__tabella[plx][ply]
                self.__tabella[plx].insert(ply,"X")
                del self.__campo[plx][ply]
                self.__campo[plx].insert(ply,"X")
            
    def stampaBella(self):
        for i in range(len(self.__campo)):
            for j in range(len(self.__campo[i])):
                print(self.__campo[i][j],end="\t")
            print()
    def stampaBella2(self):
        for i in range(len(self.__tabella)):
            for j in range(len(self.__tabella[i])):
                print(self.__tabella[i][j],end="\t")
            print()

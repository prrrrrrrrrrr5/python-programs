class Molecola:
    def __init__(self,simbolo,elett):
        self.__simbolo=simbolo
        self.__elettr=elett

    def divisioni(self):
        numeri="1234567890"
        alfabeto="abcdefghijklmnopqrstuvwxyz"
        self.__divisioni=[]
        for i in self.__simbolo:
            if i in numeri and self.__simbolo.index(i)<=3:
                index=self.__simbolo.index(i)
                self.__divisioni.append(self.__simbolo[:index+1])
                self.__divisioni.append(self.__simbolo[index+1:])
                break
        if self.__divisioni==[]:
            for i in self.__simbolo:
                if i in alfabeto:
                    index=self.__simbolo.index(i)
                    self.__divisioni.append(self.__simbolo[:index+1])
                    self.__divisioni.append(self.__simbolo[index+1:])
                    break            
    
    def getDivisioni(self):
        self.divisioni()
        return self.__divisioni
    
    def getElettr(self):
        return self.__elettr
    
    def getSimbolo(self):
        return self.__simbolo